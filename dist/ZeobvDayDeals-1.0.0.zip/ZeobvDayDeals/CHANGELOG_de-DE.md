# 1.0.0
- Erste Version für Shopware 6
