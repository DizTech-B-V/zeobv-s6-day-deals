# 3.0.0

-   6.6 Kompatibilität hinzugefügt

# 2.0.1

-   Fehlerhafte Anzeige des Preises behoben

# 2.0.0

-   6.5 Kompatibilität hinzugefügt

# 1.0.0

-   Erste Version für Shopware 6
