# 2.0.0

-   6.5 Kompatibilität hinzugefügt

# 1.0.0

-   Erste Version für Shopware 6
